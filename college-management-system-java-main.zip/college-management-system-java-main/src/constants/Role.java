package constants;


public enum Role {
    ADMIN, FACULTY, STUDENT;
}
